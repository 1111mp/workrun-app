from workrun_sdk.tool import tool


@tool(
    name="get_weather",
    description="Get the current weather for a city.",
)
def get_weather(city: str) -> dict[str, object]:
    return {
        "city": city,
        "temperatureC": 17.3,
        "condition": "light rain",
        "observationId": "workrun-weather-test-7f3a91",
    }
